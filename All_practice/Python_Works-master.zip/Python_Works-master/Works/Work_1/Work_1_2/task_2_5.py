import math
from math import tan, atan, log10, cos , sin
x=input("Введи х")
v= x-tan(2)
u=4*atan(1)+log10(x)
y=cos(u)+8*sin(3*v)
print (round(y,3))
# не поддерживаемый оператор для данных типов