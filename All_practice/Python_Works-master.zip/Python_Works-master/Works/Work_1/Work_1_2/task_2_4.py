longString = "This is a very long string which needs
#не закрытые кавычки