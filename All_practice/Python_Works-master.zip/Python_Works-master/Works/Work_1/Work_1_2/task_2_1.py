# SyntaxError: invalid syntax
a = 10
b = 15
result = 0
def fun(x,y):
    return x y
result = fun(a,b)
print(result)