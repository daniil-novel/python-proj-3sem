from math import log
log(-1)
