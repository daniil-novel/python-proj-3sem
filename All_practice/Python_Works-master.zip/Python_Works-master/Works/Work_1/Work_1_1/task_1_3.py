import sys
# в python 3 нет ограницения на int
# в puthon 2 есть. Максимальное число: sys.maxint
print(sys.float_info)

