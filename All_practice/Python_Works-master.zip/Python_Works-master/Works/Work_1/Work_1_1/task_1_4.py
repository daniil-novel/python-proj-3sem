print(divmod(10, 3))
