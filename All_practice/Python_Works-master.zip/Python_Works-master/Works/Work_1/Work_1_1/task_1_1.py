import this
import antigravity # 1
import __hello__ # 2
#from __future__ import braces # 3
assert 1 > 2

