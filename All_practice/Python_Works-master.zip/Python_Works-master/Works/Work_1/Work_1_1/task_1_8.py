print((True * 2 + False) * -True)
print(int(True))
print(int(False))
