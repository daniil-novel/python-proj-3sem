x = int(input())
print(x)


def task_1(x):
    print(x+x+x+x+x)

