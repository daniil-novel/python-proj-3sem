print("Module 2 loaded")

def hello():
    print("Hello from module 2")