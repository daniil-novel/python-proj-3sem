import module2

print("Module 1 loaded")

module2.hello()