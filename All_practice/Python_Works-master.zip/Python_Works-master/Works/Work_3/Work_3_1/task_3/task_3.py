import some_module
some_module.GLOBAL_VAR = 42
print(some_module.GLOBAL_VAR)