# my_module.py
__all__ = ["function1", "variable1"]


def function1():
    pass


def function2():
    pass


variable1 = 42

_variable2 = "private"
