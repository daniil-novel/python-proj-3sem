#E701 multiple statements on one line (colon)

x = 1
if x > 5: y = 10