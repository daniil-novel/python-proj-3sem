#E231 missing whitespace after ','

my_tuple = 1,2,3