#E302 expected 2 blank lines, found 1

def func1():
    pass

def func2():
    pass