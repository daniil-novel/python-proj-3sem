#E211 whitespace before '('

with open ('file.dat') as f:
    contents = f.read()