#E225 missing whitespace around operator

age = 10
if age>15:
    print('Can drive')