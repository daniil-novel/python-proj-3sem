#E702 multiple statements on one line (semicolon)

from gevent import monkey; monkey.patch_all()