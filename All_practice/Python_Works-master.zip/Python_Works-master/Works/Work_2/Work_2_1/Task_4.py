#E251 unexpected spaces around keyword / parameter equals

def func(key1 = 'val1',
         key2 = 'val2'):
    return key1, key2