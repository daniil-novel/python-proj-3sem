#E712 comparison to True should be 'if cond is True:' or 'if cond:'

x = True
if x == True:
    print('True!')