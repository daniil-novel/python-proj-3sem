#https://tproger.ru/translations/asterisks-in-python-what-they-are-and-how-to-use-them/
def get_multiple(*keys, dictionary):
    return dictionary

print(get_multiple("Hello"))

