i = 0
print('mcwuoocdwhe'[i::3])
