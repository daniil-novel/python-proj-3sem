s = ['1', '2', '3']; print([int(i) for i in s])
