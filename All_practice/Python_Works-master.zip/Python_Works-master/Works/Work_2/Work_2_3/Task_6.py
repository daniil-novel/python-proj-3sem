s = ["My", "name", "is", "Alex"]; print(max(s, key=len))
