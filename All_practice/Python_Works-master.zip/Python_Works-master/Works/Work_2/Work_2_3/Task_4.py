s = [1, 2, 3, 3, 4, 4]; x = 3; print([i for i in range(1, len(s)) if s[i] == x])
