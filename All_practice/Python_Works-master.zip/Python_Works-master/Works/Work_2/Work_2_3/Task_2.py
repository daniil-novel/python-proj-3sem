s = [1, 2, 3, 3, 4, 4]; print(len(set(s)))
