def group_generation():
    groups = ['ИВБО', 'ИКБО', 'ИМБО', 'ИНБО']
    number_of_groups = [8, 33, 2, 13]
    final = []
    for i in range(len(groups)):
        for j in range(number_of_groups[i]):
            if j != 22 and j != 28:
                final.append(f'{groups[i]}-{j + 1}-21')
    for i in range(len(final)):
        if i == number_of_groups[]
    return


group_generation()
