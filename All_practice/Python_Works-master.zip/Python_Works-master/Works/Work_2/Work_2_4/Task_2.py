import sys


def myprint(to_print):
    sys.stdout.write("By me: " + str(to_print))


myprint("Hello world!")
