n = int(input())
while n != 0:
    print(n*2)
    n = int(input())