import Fabric_module

if __name__ == "__main__":
    var = Fabric_module.load_config("moduleTest.py")
    print(var)