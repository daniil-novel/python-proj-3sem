from module1 import *

if __name__ == "__main__":
    print(GLOBAL_VAR1)
    print(GLOBAL_VAR2)
    print(GLOBAL_VAR3)