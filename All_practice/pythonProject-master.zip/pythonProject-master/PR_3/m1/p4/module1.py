GLOBAL_VAR1 = "value1"
GLOBAL_VAR2 = "value2"
GLOBAL_VAR3 = "value3"

__all__ = ['GLOBAL_VAR1', 'GLOBAL_VAR2']