def bye():
    print("Bye from module2!")