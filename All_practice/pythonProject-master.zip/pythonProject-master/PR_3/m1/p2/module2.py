print("Module 2 loaded")

var2 = "World"