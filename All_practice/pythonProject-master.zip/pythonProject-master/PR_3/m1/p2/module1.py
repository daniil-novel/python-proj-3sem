print("Module 1 loaded")

var1 = "Hello"