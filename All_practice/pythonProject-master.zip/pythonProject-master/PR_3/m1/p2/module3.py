import module1
import module2

print(module1.var1)
print(module2.var2)