import module3

if __name__ == "__main__":
    module3
    module3
    module3