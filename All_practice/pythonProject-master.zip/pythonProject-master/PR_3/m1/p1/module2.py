import module1

var2 = "World"

print(module1.var1)