import module2

var1 = "Hello"

print(module2.var2)