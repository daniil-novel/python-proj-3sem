import math
"""
def one(x, y):
    return x y

def two():
    "abc" = int(4)

def three():
    integer = 1
    print(inteeger)

def four():
    print("ла ла ла ла)

def five(x , y):
    a = x / y

def six():
    for i in range(10):
    print(i)

def seven():
    a = 1
    b = 2
    if b > a:
        print(1)
    elif a == b:
        print(2)
     else:
        print(3)

def eight():
    print(math.sqrt(-1))

def nine():
    results = []
    for i in range(1000):
        results.append(math.exp(i))
        print(results[i-1])



if __name__ == "__main__":
    #print(one(10, 15))
    #two()
    #three()
    #four()
    #five("2", "3")
    #six()
    #seven()
    #eight()
    #nine()
"""
