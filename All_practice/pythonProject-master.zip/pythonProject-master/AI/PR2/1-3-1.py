import numpy as np




if __name__ == "__main__":
    arr = np.random.random((3,3,3))
    print(arr)